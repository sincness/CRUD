<html>
<head>
    <title>Create user</title>
</head>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
      <link rel="stylesheet" href="alternate/create.css">
<form action="create.php" method="post" name="form1">
        <tr>
          <label class="first">Username</label>
          <input type="text" name="name" />
        </tr>
        <tr>
          <label>Email</label>
          <input type="text" name="email" />
        </tr>
        <tr>
          <label>Password</label>
          <input type="text" name="pass" />
        </tr>
        <tr class="buttons">
          <td><button id="create" type="submit" name="Submit"><i class="material-icons">create</i></button></td>
          <td><button id="cancel" type="button" value="Cancel" onclick="window.location='index.php';"><i class="material-icons">cancel</i></button></td>
        </tr>
    </form>

<body>
<?php
//including the database connection file
include_once "alternate/db.php";
if (isset($_POST['Submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];

    echo '<section class="messages">';

    // checking empty fields
    if (empty($name) || empty($email) || empty($pass)) {
        if (empty($name)) {
            echo "<font color='red'>Name field is empty.</font><br/>";
        }
        if (empty($email)) {
            echo "<font color='red'>Email field is empty.</font><br/>";
        }
        if (empty($pass)) {
            echo "<font color='red'>Password field is empty.</font><br/>";
        }
        //link to the previous page
        echo '<br/><a href="index.php">Go Back</a>';
    } else {
        // if all the fields are filled (not empty)
        //insert data to database
        $sql = "INSERT INTO users(username, email, password) VALUES(:name, :email, :pass)";
        $query = $dbConn->prepare($sql);
        $query->bindparam(':name', $name);
        $query->bindparam(':email', $email);
        $query->bindparam(':pass', $pass);
        $query->execute();
        // Alternative to above bindparam and execute
        // $query->execute(array(':name' => $name, ':email' => $email, ':pass' => $pass));
        //display success message
        echo "<font color='green'>Data added successfully.";
        echo "<br/><a href='index.php'>View Result</a>";
    }
    echo '</section>';
}
?>
</body>
</html>