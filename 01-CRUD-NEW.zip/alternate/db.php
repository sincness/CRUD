<?php
$host = 'localhost';
$dbname = 'crud';
$user = 'root';
$pass = 'root';

try {
    $dbConn = new PDO("mysql:host={$host};dbname={$dbname}", $user, $pass);
    $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Setting Error Mode as Exception
    // echo 'Tilsluttet';
} catch (PDOException $e) {
    echo "Fejl, ingen tilslutning:".$e->getMessage();
}