<?php
ini_set('display_errors', 1);
error_reporting('E_ALL');
include('../alternate/db.php');

$id = $_POST['id'];
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];


$query = 'UPDATE users SET username = :username, email = :email, password = :password WHERE id = :id';




$stmt = $dbConn->prepare($query);
$stmt->execute(array(':id' => $id, ':username' => $username, ':email' => $email, ':password' => $password));
echo '
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
rel="stylesheet">
<link rel="stylesheet" href="/01-CRUD/alternate/success.css">';
echo '<section class="wrapper"><br /><br /><p>Update was commited<p> <br />';
echo '<a href="/01-CRUD/./index.php">Back to index</a></section>';
// header('location:index.php');

?>