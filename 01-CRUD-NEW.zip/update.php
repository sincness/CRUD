<?php

include ('alternate/db.php');


$id = $_GET['id'];



$stmt = $dbConn->prepare("SELECT * FROM users WHERE id=".$id);
$stmt->execute();



echo'
<script src="https://kit.fontawesome.com/3e052f9cf3.js" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="alternate/update.css">

<table width="80%" border="0">

	<tr bgcolor="#CCCCCC">
		<th>Username</th>
		<th>Email</th>
		<th>Password</th>
		<th>Actions</th>
    </tr>
';
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
{ 		
    echo '<tr>';
    echo '<form action="success/update_success.php" method="POST">';
    echo '<td><input name="username" type="text" value="'.$row['username'].'"/></td>';
    echo '<td><input name="email" type="text" value="'.$row['email'].'"/></td>';
    echo '<td><input name="password" type="text" value="'.$row['password'].'"/></td>';
    echo '<input type="hidden" id="id" name="id" value="'.$id.'"/>';
    echo "<td><button name='send' type='submit' class='update' onClick=\"return confirm('Are you sure you want to confirm?')\" href=\"success/update_success.php?id=$row[id]\"><i style='color:green;' class='fas fa-check'></i></button></button> <a style='color:darkred;' class='delete' href=\"index.php\"><i class='fas fa-window-close'></i></a></td>";		
    echo '</form>';
    echo '<tfoot><tr><td>1</td><td>1</td><td>1</td><td>1</td></tr></tfoot>';
} 

?>